package com.licunzhi.service;

import java.util.List;

import com.licunzhi.model.Page;

/**
 * PageService
 */
public interface PageService extends BaseService<Page> {


}
