package com.licunzhi.service;

import com.licunzhi.model.Questions;

/**
 * QuestionsService
 */
public interface QuestionsService extends BaseService<Questions> {

}
