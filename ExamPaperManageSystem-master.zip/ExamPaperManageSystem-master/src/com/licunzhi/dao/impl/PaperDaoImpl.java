package com.licunzhi.dao.impl;

import org.springframework.stereotype.Repository;
import com.licunzhi.model.Paper;

/**
 * �����Ծ�dao
 * @author LiCunzhi
 *
 */
@Repository("paperDao")
public class PaperDaoImpl extends BaseDaoImpl<Paper> {
}
