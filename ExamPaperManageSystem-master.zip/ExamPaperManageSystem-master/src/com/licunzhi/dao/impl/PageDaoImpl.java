package com.licunzhi.dao.impl;

import org.springframework.stereotype.Repository;
import com.licunzhi.model.Page;

/**
 * ����ҳ��dao 
 * @author LiCunzhi
 *
 */
@Repository("pageDao")
public class PageDaoImpl extends BaseDaoImpl<Page> {
}
